# Mini Project — Exploratory Data Analysis on India's COVID-19 Data

## Project goal
Uncover state-wise trends, recovery rates, and vaccination progress in India's COVID-19 pandemic using NumPy, Pandas, Matplotlib, and Seaborn.

## Included
- `COVID19_India_EDA_Mini_Project.ipynb` — complete project notebook
- `requirements.txt` — Python dependencies

## Data sources
The notebook loads both datasets live with `pandas.read_csv()`:
1. India COVID-19 case data from `imdevskp/covid-19-india-data`
2. India vaccination data from Our World in Data (OWID)

No manual dataset download is required.

## Notebook workflow
Load → Inspect → Clean → Explore (groupby/pivot) → Visualise (12 charts) → Save cleaned dataset → Written summary

## Run
1. Install dependencies:
   `pip install -r requirements.txt`
2. Start Jupyter:
   `jupyter notebook`
3. Open `COVID19_India_EDA_Mini_Project.ipynb`
4. Run all cells from top to bottom.

The cleaned case dataset is saved by the notebook as `cleaned_covid_india.csv`.
